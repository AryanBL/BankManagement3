#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
node frontend-server.js
